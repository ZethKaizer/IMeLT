<?php 
include('connection.php');
include('tags.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
</head>
<body>
<?php 
if(isset($_POST["login"]))
{
$count = 0;    
$username = $_POST['username'];  
$password = $_POST['password'];  
$res = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials WHERE username='$username' && password='$password'");
$count = mysqli_num_rows($res);    

    if($count == 0) { 
    echo '<div class="alert alert-danger alertClass">
    <center>
    <!--  <button type="button" class="close" data-dismiss="alert">&times;</button> -->

    <strong>Invalid</strong> Username Or Password.
    </center>
    </div> ';
    }
  
    else { 
    $_SESSION["username"] = $username;

    echo '<script>
    window.location="index.php";
    </script> ';

    }
}
?>
<div class="row h-100 fontStyle">
    <div class="col-lg-6" style="background-color: white;">
        <div class="box">
            <div class="box-cell">  
                <a href="../user/index.php">
                    <button class="btn btn-primary" style="margin-left: 20px;">
                        <span class="glyphicon glyphicon-chevron-left"></span> Back
                    </button>
                </a>             
                    <div class="login-box-cell">
                        <div class="login-panel">
                            <div class="row text-center">
                                <img src="assets/img/icon2.png" width="100"/>
                            </div>
                            <br>
                            <h6 class="text-center lead mt-4" style="font-size: 18px; font-weight: bold;">iMelt Portal</h6>
                            
                            <form action="" method="post">
                                <div class="form-group-sm ">
                                    <h6 for="username" style="font-size: 14px;">Username:</h6>
                                    <input type="text" name="username"  class="form-control form-control-sm mb-4" maxlength="11" required>
                                </div>
                                <div class="form-group-sm">
                                    <h6 for="password" style="font-size: 14px;">Password:</h6>
                                    <input type="password" name="password"  class="form-control form-control-sm" maxlength="11" required>
                                </div>
                                <div class="form-group-sm mb-4" style="margin-top: 14px;">
                                    <span><input type="submit" class="btn btn-block btn-primary" style="border-radius: 50px;" value="LOGIN" name="login"></span>
                            </form>
                        </div>
                        <div class="form-group-sm" style="margin-top: 14px; margin-bottom: 14px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 hide-lg d-none-pic">
        <img src="assets/img/imus_bg.png"  style="height: 100vh !important; zoom: 100%;"/>
    </div>
</div>
</body>
</html>
