<?php 
session_start();
include('connection.php');
include('tags.php');
include('sidebar.php');
?>   



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMeLT</title>
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">
    
</head>
<body>
<?php 
$res = mysqli_query($conn, "SELECT DISTINCT module_num, module_name FROM tbl_modules");
      if($res){
        $rowcount = mysqli_num_rows($res);
      }
?>

<div class="container" style="max-width: 800px;">
	
    <center>
    	<!--
  <a href="../index.php"><img src="assets/img/IMeLTLogo.png" class="mx-auto img-fluid" width="250" /></a>
-->
</center>

  <br>
  <div class="" style="margin-top: -20px;"> <!-- lineBorder -->
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
    <br>    
        <div class="row">
                <div class="col-lg-12">
                	<div class="form-group">
                			<a href="#">
 <?php while($row = mysqli_fetch_array($res)){ ?>

          <div class="btn-group-vertical buttonQuizPage" style="">

          	<?php echo $row["module_num"]; echo " - "; echo $row["module_name"]; ?> 
          </div>
         <?php  ?> 
        <?php
        }
        ?>
    </a>
</div>
            </div>
        </div>
        <br>
    </div>
</div>
</body>
</html>
