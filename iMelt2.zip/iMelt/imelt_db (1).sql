-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2020 at 05:53 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `imelt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_answers`
--

CREATE TABLE `tbl_answers` (
  `answer_id` int(11) NOT NULL,
  `answer` varchar(200) NOT NULL,
  `ans_id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lesson_contents`
--

CREATE TABLE `tbl_lesson_contents` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lesson_contents` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_lesson_contents`
--

INSERT INTO `tbl_lesson_contents` (`module_id`, `module_num`, `module_name`, `lesson_contents`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere ', 'Component of the Earth\'s Atmosphere'),
(2, 'Module 1', 'Earth\'s Atmosphere', 'Vertical Structure of the Atmosphere'),
(3, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Temperature and Heat Transfer'),
(4, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiant Energy'),
(5, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiation-Absorption, Emission and Equilibrium'),
(6, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Earth\"s Seasons'),
(7, 'Module 3', 'Air Temperature', 'Warming and Cooling Air Near the Surface'),
(8, 'Module 3', 'Air Temperature', 'Measuring Air Temperature'),
(9, 'Module 4', 'Humidity, Condensation and Clouds', 'Circulation of Water in the Atmosphere'),
(10, 'Module 4', 'Humidity, Condensation and Clouds', 'Evaporation, Condensation, and Saturation'),
(11, 'Module 4', 'Humidity, Condensation and Clouds', 'Humidity'),
(12, 'Module 4', 'Humidity, Condensation and Clouds', 'Dew and Frost'),
(13, 'Module 4', 'Humidity, Condensation and Clouds', 'Fog'),
(14, 'Module 4', 'Humidity, Condensation and Clouds', 'Foggy Weather'),
(15, 'Module 4', 'Humidity, Condensation and Clouds', 'Clouds'),
(16, 'Module 5', 'Cloud Development and Precipitation', 'Atmospheric Stability'),
(17, 'Module 5', 'Cloud Development and Precipitation', 'Cloud Development and Stability'),
(18, 'Module 5', 'Cloud Development and Precipitation', 'Precipitation Process'),
(19, 'Module 6', 'Air Pressure and Winds', 'Atmospheric Pressure'),
(20, 'Module 6', 'Air Pressure and Winds', 'Winds and Vertical Air Motions');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_modules`
--

CREATE TABLE `tbl_modules` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL,
  `lesson_contents` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_modules`
--

INSERT INTO `tbl_modules` (`module_id`, `module_num`, `module_name`, `lesson_contents`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere ', 'Component of the Earth\'s Atmosphere'),
(2, 'Module 1', 'Earth\'s Atmosphere', 'Vertical Structure of the Atmosphere'),
(3, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Temperature and Heat Transfer'),
(4, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiant Energy'),
(5, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Radiation-Absorption, Emission and Equilibrium'),
(6, 'Module 2', 'Warming and Cooling Earth and its Atmosphere', 'Earth\"s Seasons'),
(7, 'Module 3', 'Air Temperature', 'Warming and Cooling Air Near the Surface'),
(8, 'Module 3', 'Air Temperature', 'Measuring Air Temperature'),
(9, 'Module 4', 'Humidity, Condensation and Clouds', 'Circulation of Water in the Atmosphere'),
(10, 'Module 4', 'Humidity, Condensation and Clouds', 'Evaporation, Condensation, and Saturation'),
(11, 'Module 4', 'Humidity, Condensation and Clouds', 'Humidity'),
(12, 'Module 4', 'Humidity, Condensation and Clouds', 'Dew and Frost'),
(13, 'Module 4', 'Humidity, Condensation and Clouds', 'Fog'),
(14, 'Module 4', 'Humidity, Condensation and Clouds', 'Foggy Weather'),
(15, 'Module 4', 'Humidity, Condensation and Clouds', 'Clouds'),
(16, 'Module 5', 'Cloud Development and Precipitation', 'Atmospheric Stability'),
(17, 'Module 5', 'Cloud Development and Precipitation', 'Cloud Development and Stability'),
(18, 'Module 5', 'Cloud Development and Precipitation', 'Precipitation Process'),
(19, 'Module 6', 'Air Pressure and Winds', 'Atmospheric Pressure'),
(20, 'Module 6', 'Air Pressure and Winds', 'Winds and Vertical Air Motions');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module_name`
--

CREATE TABLE `tbl_module_name` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_module_name`
--

INSERT INTO `tbl_module_name` (`module_id`, `module_num`, `module_name`) VALUES
(1, 'Module 1', 'Earth\'s Atmosphere '),
(2, 'Module 1', 'Earth\'s Atmosphere'),
(3, 'Module 2', 'Warming and Cooling Earth and its Atmosphere'),
(4, 'Module 2', 'Warming and Cooling Earth and its Atmosphere'),
(5, 'Module 2', 'Warming and Cooling Earth and its Atmosphere'),
(6, 'Module 2', 'Warming and Cooling Earth and its Atmosphere'),
(7, 'Module 3', 'Air Temperature'),
(8, 'Module 3', 'Air Temperature'),
(9, 'Module 4', 'Humidity, Condensation and Clouds'),
(10, 'Module 4', 'Humidity, Condensation and Clouds'),
(11, 'Module 4', 'Humidity, Condensation and Clouds'),
(12, 'Module 4', 'Humidity, Condensation and Clouds'),
(13, 'Module 4', 'Humidity, Condensation and Clouds'),
(14, 'Module 4', 'Humidity, Condensation and Clouds'),
(15, 'Module 4', 'Humidity, Condensation and Clouds'),
(16, 'Module 5', 'Cloud Development and Precipitation'),
(17, 'Module 5', 'Cloud Development and Precipitation'),
(18, 'Module 5', 'Cloud Development and Precipitation'),
(19, 'Module 6', 'Air Pressure and Winds'),
(20, 'Module 6', 'Air Pressure and Winds');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_module_num`
--

CREATE TABLE `tbl_module_num` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_module_num`
--

INSERT INTO `tbl_module_num` (`module_id`, `module_num`) VALUES
(1, 'Module 1'),
(2, 'Module 2'),
(3, 'Module 3'),
(4, 'Module 4'),
(5, 'Module 5'),
(6, 'Module 6');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_questions`
--

CREATE TABLE `tbl_questions` (
  `module_id` int(12) NOT NULL,
  `module_num` varchar(26) NOT NULL,
  `module_questions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_credentials`
--

CREATE TABLE `tbl_user_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_credentials`
--

INSERT INTO `tbl_user_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'Bragais', 'Mikee', '', 'mikee04', 'mikee04'),
(2, 'rw', 'rw', 'rw', 'rw', 'rw'),
(3, 'rw', 'rw', 'rw', 'rw', 'rw'),
(4, 'rw', 'rw', 'rw', 'rw', 'rw'),
(5, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(6, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(7, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(8, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(9, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(10, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(11, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(12, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(13, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(14, 'gsga', 'ggsagsaga', 'gsga', 'gsgagg', 'sgagagga'),
(15, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(16, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(17, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(18, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(19, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(20, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(21, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(22, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(23, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(24, 'Lastica', 'Mark Aldrin', 'Lastica', 'markaldrin04', 'markaldrin04'),
(25, 'sasa', 'jjijiji', 'sasa', 'jijijijjiji', 'jijiji'),
(26, 'sasa', 'jjijiji', 'sasa', 'jijijijjiji', 'jijiji'),
(27, '8899', '999', '8899', '999', '9999'),
(28, '8899', '999', '8899', '999', '9999'),
(29, '8899', '999', '8899', '999', '9999');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_answers`
--
ALTER TABLE `tbl_answers`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `tbl_lesson_contents`
--
ALTER TABLE `tbl_lesson_contents`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_module_name`
--
ALTER TABLE `tbl_module_name`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_module_num`
--
ALTER TABLE `tbl_module_num`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_answers`
--
ALTER TABLE `tbl_answers`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_lesson_contents`
--
ALTER TABLE `tbl_lesson_contents`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_modules`
--
ALTER TABLE `tbl_modules`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_module_name`
--
ALTER TABLE `tbl_module_name`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_module_num`
--
ALTER TABLE `tbl_module_num`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  MODIFY `module_id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user_credentials`
--
ALTER TABLE `tbl_user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
